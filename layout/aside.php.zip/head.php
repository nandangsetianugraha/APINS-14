<!DOCTYPE html>
<html lang="en" dir="ltr" data-theme="light">

<head>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&amp;family=Roboto+Mono&amp;display=swap" rel="stylesheet">
	<link href="<?=base_url();?>assets/build/styles/ltr-core.css" rel="stylesheet">
	<link href="<?=base_url();?>assets/build/styles/ltr-vendor.css" rel="stylesheet">
	<link href="<?=base_url();?>assets/images/logo.ico" rel="shortcut icon" type="image/x-icon">
	<title><?=$data;?> | <?=$apps['nama'];?> v<?=$apps['versi'];?></title>
    <style>
 
    </style>