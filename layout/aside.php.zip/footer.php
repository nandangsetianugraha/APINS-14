			<div class="footer">
				<div class="container-fluid g-5">
					<div class="row g-3">
						<div class="col-sm-6 text-center text-sm-start">
							<p class="mb-0"><i class="far fa-copyright"></i> <span id="copyright-year"></span> SD Islam Al-Jannah</p>
						</div>
						<div class="col-sm-6 text-center text-sm-end">
							<p class="mb-0"><?=$apps['nama'];?> v<?=$apps['versi'];?></p>
						</div>
					</div>
				</div>
			</div>
			
			